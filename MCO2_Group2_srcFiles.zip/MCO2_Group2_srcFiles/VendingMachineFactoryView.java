import javax.swing.*;
import javax.swing.border.Border;

import java.awt.*;
import java.awt.event.ActionListener;

/**
 * This class contains is the inner workings of what the user sees through the gui
 *
 * @author Group2(Flores,Ranigo)
 */
public class VendingMachineFactoryView {
    /**
     * This constructor will initialize the attributes of the class, as well as set up the GUI
     */
    public VendingMachineFactoryView(){
        this.mainFrame = new JFrame("Vending Machine Factory");

        this.mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.mainFrame.setLayout(null);
        this.mainFrame.setSize(500, 500);
        this.mainFrame.setResizable(false);

        this.textArea = new JTextArea();
        this.textArea.setText(" Please select a Vending Machine\n   and the Feature you wish to try");
        this.textArea.setBounds(130, 50, 200, 40);
        this.textArea.setFont(new Font("Helvetica", 1, 12));
        this.textArea.setBorder(BorderFactory.createLineBorder(Color.black));
        this.textArea.setEditable(false);

       String[] type = {"", "Normal Vending Machine", "Special Vending Machine"};
       this.machineType = new JComboBox(type);
       this.machineType.setBounds(130, 140, 200, 45);
       ((JLabel)this.machineType.getRenderer()).setHorizontalAlignment(SwingConstants.HORIZONTAL);
       this.machineType.setBorder(BorderFactory.createLineBorder(Color.black));
       this.machineType.setEditable(false);

       this.create = new JButton("Create");
       this.create.setBorder(BorderFactory.createLineBorder(Color.black));
       this.test = new JButton("Test");
       this.test.setBorder(BorderFactory.createLineBorder(Color.black));
       this.maintenance = new JButton("Maintenance");
       this.maintenance.setBorder(BorderFactory.createLineBorder(Color.black));

       JPanel buttonHold = new JPanel(new GridLayout(1, 3));
       buttonHold.setBounds(60, 250, 350, 75);
       buttonHold.add(create);
       buttonHold.add(test);
       buttonHold.add(maintenance);



       this.mainFrame.add(machineType, BorderLayout.CENTER);
       this.mainFrame.add(textArea);
       this.mainFrame.add(buttonHold);
       this.mainFrame.setVisible(true);
    }

    //Setters
    public void setTextArea( String text ){ this.textArea.setText(text); }
    public void setCreate( ActionListener actionListener ){ this.create.addActionListener(actionListener); }
    public void setTest( ActionListener actionListener ){ this.test.addActionListener(actionListener); }
    public void setMaintenance(ActionListener actionListener){ this.maintenance.addActionListener(actionListener); }

    //Getters
    public JComboBox getMachineType(){return machineType;}


    //Attributes

    private JFrame mainFrame;
    private JTextArea textArea;
    private JComboBox machineType;
    private JButton create, test, maintenance;
}
