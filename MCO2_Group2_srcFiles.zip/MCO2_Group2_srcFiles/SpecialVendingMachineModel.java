/**
 * This class is responsible for the inner workings inside the special vending machine.
 * @author Group 2(Flores, Ranigo)
 */
public class SpecialVendingMachineModel {
    /**
     * The constructor is responsible for initializing the slots and the cash register to manage the transactions.
     * @param slots The slots of the vending machine that will store items.
     */
    public SpecialVendingMachineModel( Slot[] slots ){
        this.slots = slots;
        cashRegister = new CashRegister();
    }

    /**
     * This method returns the slots of the vending machine.
     * @return Vending machine slots.
     */
    public Slot[] getSlots(){ return slots;}

    /**
     * This method returns the cash register of the vending machine.
     * @return Vending machine cash register.
     */
    public CashRegister getCashRegister(){ return cashRegister; }

    private Slot[] slots;
    private CashRegister cashRegister;
}
