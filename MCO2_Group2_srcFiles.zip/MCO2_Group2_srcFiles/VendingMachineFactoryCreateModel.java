/**
 * This class holds the attributes and methods of the custom create feature
 */
public class VendingMachineFactoryCreateModel {
    /**
     * This constructor initializes the array of slot for the user
     */
    public VendingMachineFactoryCreateModel(){
        this.slots = null;
    }

    /**
     * This method sets the custom selected slot amount
     * @param amount holds the amount of slots the user wants
     */
    public void setSlots(int amount){
        this.slots = new Slot[amount];
    }

    public Slot[] getSlots(){ return slots; }

    /***
     * this method initializes a normal vending machine model using the slots as parameter
     * @param slot used as parameter to construct a new vending machine model
     */
    public void initializeVendingMachineModel( Slot[] slot ){
        this.vendingMachineModel = new VendingMachineModel(slot);
    }

    /**
     * This method initializes a special vending machine model using the slots as parameter
     * @param slot used as parameter to construct a new special vending machine model
     */
    public void initializeSpecialVendingMachineModel( Slot[] slot ){
        this.specialVendingMachineModel = new SpecialVendingMachineModel(slot);
    }

    public VendingMachineModel getVendingMachineModel(){return vendingMachineModel;}
    public SpecialVendingMachineModel getSpecialVendingMachineModel(){return specialVendingMachineModel;}

    /**
     * This method will set the current slots into the preset version of the Vending machine
     * @param select holds index to choose between normal or special vending machine
     */
    public void setPresent( int select ){
        Item[] items = new Item[10];
        items[0] = new Item("Carbonara Pasta", 40, 150, true);
        items[1] = new Item("Spaghetti Pasta", 40, 150, true);
        items[2] = new Item("Ridged Pasta", 35, 130, true);
        items[3] = new Item("Fusilli Pasta", 40, 160, true);
        items[4] = new Item("Red Sauce", 20, 80, false);
        items[5] = new Item("White Sauce", 30, 90, false);
        items[6] = new Item("Pesto Sauce", 50, 100, false);
        items[7] = new Item("Meat Balls", 60, 200, true);
        items[8] = new Item("Beef Bits", 50, 180, true);
        items[9] = new Item("Hot Dogs", 20, 160, true);

        this.slots = new Slot[10];
        for(int j = 0; j < slots.length; j++) {
            slots[j] = new Slot();
            slots[j].addItem(items[j],10);
        }

        switch( select ){
            case 1:
                vendingMachineModel = new VendingMachineModel(slots);
                break;
            case 2:
                specialVendingMachineModel = new SpecialVendingMachineModel(slots);
                break;
        }
    }

    private Slot[] slots;
    private VendingMachineModel vendingMachineModel;
    private SpecialVendingMachineModel specialVendingMachineModel;
}
