import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * This class holds the controller for the custom slot creation feature
 *
 * @author Group2(Flores,Ranigo)
 */
public class VendingMachineFactoryCreateController {
    /**
     * This constructor will initialize the controller with a VendingMachineFactoryCreateView and VendingMachineFactoryCreateModel as parameters
     * @param createView holds the inner workings of the GUIs visuals
     * @param createModel holds the attributes and methods of the class
     * @param i holds the selected index from either normal vending machine or special vending machine
     */
    public VendingMachineFactoryCreateController(VendingMachineFactoryCreateView createView, VendingMachineFactoryCreateModel createModel, int i ){
        this.createView = createView;
        this.createModel = createModel;

        this.createView.setSubmit1(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int number;
                switch(i){
                    case 1:
                        if (e.getSource() instanceof JButton){
                            if(createView.getInput1().getText() == null){

                            }
                            else{
                                number = Integer.parseInt(createView.getInput1().getText());
                                createView.setIntroText("Test");
                                createModel.setSlots(number);
                                createModel.initializeVendingMachineModel(createModel.getSlots());
                                System.out.println("ITS WORKED: "+ "  NUMBER OF SLOTS: "+createModel.getSlots().length);
                            }
                        }
                    break;
                    case 2:
                        if (e.getSource() instanceof JButton){
                            if(createView.getInput1().getText() == null){

                            }
                            else{
                                number = Integer.parseInt(createView.getInput1().getText());
                                createView.setIntroText("Test");
                                createModel.setSlots(number);
                                createModel.initializeSpecialVendingMachineModel(createModel.getSlots());
                            }
                        }
                    break;
                }
            }
        });


        this.createView.setPreset(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createModel.setPresent(i);
            }
        });


    }

    /**
     * This method will change the value of the view's mainframe visibility to true
     */
    public void setJFrameToVisible(){ this.createView.getMainFrame().setVisible(true); }

    private VendingMachineFactoryCreateView createView;
    private VendingMachineFactoryCreateModel createModel;
}
