import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionListener;

/**
 * This class is mainly responsible for the visuals/GUI regarding the vending machine.
 * @author Group 2(Flores, Ranigo)
 */
public class SpecialVendingMachineView {
    /**
     * The constructor initializes the different core components of its GUI. It contains different aspects such as panels, labels, fonts, text area, and more.
     */
    public SpecialVendingMachineView(){
        this.mainFrame = new JFrame("MyVendingMachine");

        this.mainFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.mainFrame.setLayout(null);
        this.mainFrame.setSize(800, 930);
        this.mainFrame.getContentPane().setBackground(Color.LIGHT_GRAY);
        Font font = new Font("Helvetica", 1, 12);
        Font font2 = new Font("Helvetica", 1, 14);

        //Text Box
        textLbl = new JTextArea();
        textLbl.setEditable(false);
        textLbl.setFont(font);
        JPanel textPanel = new JPanel( new FlowLayout(FlowLayout.CENTER));
        textPanel.setBounds(25, 20, 200, 270);
        textPanel.setBackground(Color.white);
        textPanel.setBorder(BorderFactory.createLineBorder(Color.black));
        textPanel.add(textLbl);

        //Item Window
        itemsLbl = new JTextArea[4];

        for(int i = 0 ; i < 3 ; i++){
            itemsLbl[i] = new JTextArea();
            itemsLbl[i].setEditable(false);
            itemsLbl[i].setFont(font2);
            itemsLbl[i].setBorder(BorderFactory.createLineBorder(Color.black));
        }

        JPanel itemsPanel = new JPanel(new GridLayout(0,3 ));
        itemsPanel.setBackground(Color.white);
        itemsPanel.setBounds(250, 20, 500, 700);
        itemsPanel.add(itemsLbl[0]);
        itemsPanel.add(itemsLbl[1]);
        itemsPanel.add(itemsLbl[2]);
        itemsPanel.setBorder(BorderFactory.createLineBorder(Color.black));

        //Dispenser Slot
        dispenseLbl = new JTextArea();
        dispenseLbl.setEditable(false);
        dispenseLbl.setFont(font);
        JPanel dispensePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        dispensePanel.setBackground(Color.white);
        dispensePanel.setBounds(380, 750, 250, 80);
        dispensePanel.add(dispenseLbl);
        dispensePanel.setBorder(BorderFactory.createLineBorder(Color.black));


        //Keypad Screen and Keypad
        keypadScreen = new JTextField();
        keypadScreen.setBounds(95, 300, 60, 30);
        keypadScreen.setEditable(false);

        numBtn = new JButton[10];
        initializeButtons();
        JPanel buttonPanel = new JPanel( new GridLayout(4,3));
        buttonPanel.setBounds(40,345, 170, 170);
        for( int i = 0 ; i < 9 ; i++ )
            buttonPanel.add(numBtn[i]);
        buttonPanel.add(enterButton);
        buttonPanel.add(numBtn[9]);
        buttonPanel.add(deleteButton);
        buttonPanel.setBorder(BorderFactory.createLineBorder(Color.black));


        //Yes or No Button
        yesButton = new JButton("Yes");
        noButton = new JButton("No");
        JPanel yesornoPanel = new JPanel(new GridLayout(1,2));
        yesornoPanel.setBounds( 65, 525, 120, 40 );
        yesornoPanel.add(yesButton);
        yesornoPanel.add(noButton);
        yesornoPanel.setBorder(BorderFactory.createLineBorder(Color.black));


        //Denominations
        String[] coins = {" ","₱1 Coin ","₱5 Coin",
                "₱10 Coin","₱20 Coin",};
        coinBox = new JComboBox(coins);
        coinBox.setEditable(false);
        coinBox.setBounds(25,580,100,50);
        coinBox.setBorder(BorderFactory.createLineBorder(Color.black));

        enterCoin = new JButton("Enter");
        enterCoin.setBounds(140,580,70,50);
        enterCoin.setBorder(BorderFactory.createLineBorder(Color.black));
        String[] bills = {" ","₱20 Bill","₱50 Bill","₱100 Bill",
                "₱200 Bill","₱500 Bill","₱1,000 Bill"};
        billBox = new JComboBox(bills);
        billBox.setEditable(false);
        billBox.setBounds(25,650,100,50);
        billBox.setBorder(BorderFactory.createLineBorder(Color.black));

        enterBill = new JButton("Enter");
        enterBill.setBounds(140,650,70,50 );
        enterBill.setBorder(BorderFactory.createLineBorder(Color.black));

        //Change Giver
        changeLbl = new JTextArea();
        changeLbl.setEditable(false);
        changeLbl.setBounds( 25, 720, 200, 140);
        changeLbl.setBackground(Color.white);
        changeLbl.setBorder(BorderFactory.createLineBorder(Color.black));
        changeLbl.setFont(font);

        giveChange = new JButton("Change");
        giveChange.setBounds(235, 740, 85, 50);
        giveChange.setBorder(BorderFactory.createLineBorder(Color.black));


        //Initialization
        this.mainFrame.add(textPanel);
        this.mainFrame.add(itemsPanel);
        this.mainFrame.add(dispensePanel);
        this.mainFrame.add(buttonPanel);
        this.mainFrame.add(yesornoPanel);
        this.mainFrame.add(keypadScreen);
        this.mainFrame.add(coinBox);
        this.mainFrame.add(billBox);
        this.mainFrame.add(enterCoin);
        this.mainFrame.add(enterBill);
        this.mainFrame.add(changeLbl);
        this.mainFrame.add(giveChange);
        this.mainFrame.setVisible(false);
    }

    /**
     * This method is responsible for the keypad displays for slot numbers of the slot machine.
     */
    private void initializeButtons(){
        numBtn[0] = new JButton("1");
        numBtn[1] = new JButton("2");
        numBtn[2] = new JButton("3");
        numBtn[3] = new JButton("4");
        numBtn[4] = new JButton("5");
        numBtn[5] = new JButton("6");
        numBtn[6] = new JButton("7");
        numBtn[7] = new JButton("8");
        numBtn[8] = new JButton("9");
        numBtn[9] = new JButton("0");
        enterButton = new JButton("Ent");
        deleteButton = new JButton("Del");
    }

    //Setters

    /**
     *This method is responsible for the detection of action for number buttons.
     * @param actionListener The detection parameter.
     */
    public void setNumBtn(ActionListener actionListener){
        int i;
        for(i = 0 ; i< 10 ; i ++){
            this.numBtn[i].addActionListener(actionListener);
        }
    }

    /**
     * This method is responsible for setting text labels in the GUI.
     * @param text String of text.
     */
    public void setTextLbl(String text){this.textLbl.setText(text);}

    /**
     * This method is responsible for setting item labels in the GUI.
     * @param condition The choice for which case in the switch statement to us.
     * @param text The string of text.
     */
    public void setItemsLbl(int condition, String text){
        switch(condition){
            case 0:
                itemsLbl[0].setText(text);
                break;
            case 1:
                itemsLbl[1].setText(text);
                break;
            case 2:
                itemsLbl[2].setText(text);
                break;
            case 3:
                itemsLbl[3].setText(text);
                break;
        }
    }

    /**
     *This method is responsible for the detection of action for the enter (keypad) button.
     * @param actionListener The detection parameter.
     */
    public void setEnterButton(ActionListener actionListener){ this.enterButton.addActionListener(actionListener); }

    /**
     *This method is responsible for the detection of action for the delete button.
     * @param actionListener The detection parameter.
     */
    public void setDeleteButton(ActionListener actionListener){ this.deleteButton.addActionListener(actionListener);}

    /**
     *This method is responsible for the detection of action for the yes button.
     * @param actionListener The detection parameter.
     */
    public void setYesButton(ActionListener actionListener){ this.yesButton.addActionListener(actionListener);}

    /**
     *This method is responsible for the detection of action for the no button.
     * @param actionListener The detection parameter.
     */
    public void setNoButton(ActionListener actionListener){ this.noButton.addActionListener(actionListener); }

    /**
     *This method is responsible for the detection of action for the enter (coin) button.
     * @param actionListener The detection parameter.
     */
    public void setEnterCoin(ActionListener actionListener){ this.enterCoin.addActionListener(actionListener);}

    /**
     *This method is responsible for the detection of action for the enter (bill) button.
     * @param actionListener The detection parameter.
     */
    public void setEnterBill(ActionListener actionListener){ this.enterBill.addActionListener(actionListener);}

    /**
     * THis method is responsible accepting text and assigning it to the keypad screen.
     * @param text The string of text.
     * @param former The former string of text.
     */
    public void setKeypadScreen( String text, String former ){
        if(former == null)
            this.keypadScreen.setText(text);
        else
            this.keypadScreen.setText(former.concat(text));
    }

    /**
     * This method is responsible for accepting text and assigning it to dispense label.
     * @param text The string of text.
     */
    public void setDispenseLbl(String text){ this.dispenseLbl.setText(text);}

    /**
     * This method is responsible for accepting text and assigning it to change label
     * @param text The string of text.
     */
    public void setChangeLbl(String text){ this.changeLbl.setText(text); }

    /**
     * This method is responsible for accepting a notification and assigning ot to give change.
     * @param actionListener The detection parameter.
     */
    public void setGiveChange(ActionListener actionListener){ this.giveChange.addActionListener(actionListener); }

    //Getters
    public JTextField getKeypadScreen(){return keypadScreen;}
    public JComboBox getCoinBox(){return coinBox;}
    public JComboBox getBillBox(){return billBox;}
    public JTextArea[] getItemsLbl(){return itemsLbl;}
    public JFrame getMainFrame(){return mainFrame;}

    //Attributes
    private JFrame mainFrame;
    private JTextField keypadScreen;
    private JTextArea textLbl, dispenseLbl, changeLbl;
    private JTextArea[] itemsLbl;
    private JButton[] numBtn;
    private JButton enterButton, deleteButton, enterCoin, enterBill, giveChange, yesButton, noButton;
    private JComboBox coinBox, billBox;
}
