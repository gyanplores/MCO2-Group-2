import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * This class is responsible for holding the controller features of the Factory
 * @author Group2(Flores, Ranigo)
 */
public class VendingMachineFactoryController {
    /**
     * This constructor initializes the factory view and model, it also creates the different functions of the attributes in the view
     *
     * @param factoryView holds the images and what the user sees
     * @param factoryModel holds the inner workings of the factory
     */
    public VendingMachineFactoryController( VendingMachineFactoryView factoryView, VendingMachineFactoryModel factoryModel ){
        this.factoryView = factoryView;
        this.factoryModel = factoryModel;

        this.factoryView.setCreate(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource() instanceof JButton){
                    System.out.println( factoryView.getMachineType().getSelectedIndex() );
                    switch( factoryView.getMachineType().getSelectedIndex() ){
                        case 1:
                            factoryModel.setCreateController(factoryModel.getCreateView(), factoryModel.getCreateModel(), 1);
                            System.out.println("ITS WORKING");
                            factoryModel.getCreateController().setJFrameToVisible();
                            break;
                        case 2:
                            factoryModel.setCreateController(factoryModel.getCreateView(), factoryModel.getCreateModel(), 2);
                            factoryModel.getCreateController().setJFrameToVisible();
                            break;
                    }
                }
            }
        });


        this.factoryView.setTest(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource() instanceof JButton){
                    switch( factoryView.getMachineType().getSelectedIndex() ){
                        case 1:
                            if(factoryModel.getCreateModel().getVendingMachineModel() != null)
                                factoryModel.setNormalVendingMachineModel( factoryModel.getCreateModel().getVendingMachineModel() );
                                factoryModel.setNormalVendingController(factoryModel.getNormalVendingMachineView(), factoryModel.getNormalVendingMachineModel());
                                factoryModel.getNormalVendingController().makeVisible();
                            break;
                        case 2:
                            if(factoryModel.getCreateModel().getSpecialVendingMachineModel() != null)
                                factoryModel.setSpecialVendingMachineModel( factoryModel.getCreateModel().getSpecialVendingMachineModel() );
                                factoryModel.setSpecialVendingMachineController(factoryModel.getSpecialVendingMachineView(), factoryModel.getSpecialVendingMachineModel());
                                factoryModel.getSpecialVendingMachineController().makeVisible();
                            break;
                    }
                }
            }
        });


    }



    //Attributes
    private VendingMachineFactoryView factoryView;
    private VendingMachineFactoryModel factoryModel;
}
