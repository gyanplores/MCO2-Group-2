public class FactoryDriver {
    public static void main(String[] args){
        VendingMachineFactoryView factoryView = new VendingMachineFactoryView();
        VendingMachineFactoryModel factoryModel = new VendingMachineFactoryModel();

        VendingMachineFactoryController factoryController = new VendingMachineFactoryController(factoryView, factoryModel);

    }
}
