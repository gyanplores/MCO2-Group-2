/**
 * This class holds the inner workings of the factory
 * It is responsible for initializing elements such as the models for special and normal vending machines
 * @author Group 2(Flores, Ranigo)
 */
public class VendingMachineFactoryModel {

    /**
     * This constructor will initialize the attributes of the factory
     */
    public VendingMachineFactoryModel(){
        normalVendingMachineView = new VendingMachineView();
        normalVendingController = null;
        normalVendingMachineModel = null;

        specialVendingMachineView = new SpecialVendingMachineView();
        specialVendingMachineController = null;
        specialVendingMachineModel = null;

        createView = new VendingMachineFactoryCreateView();
        createController = null;
        createModel = new VendingMachineFactoryCreateModel();
    }


    /**
     * this method will create the custom creation controller of the factory
     *
     * @param createView contains the view of the custom creation feature
     * @param createModel holds the inner workings and attributes of the creation feature
     * @param select holds the selected index of either normal or special vending machine
     */
    public void setCreateController(VendingMachineFactoryCreateView createView, VendingMachineFactoryCreateModel createModel ,  int select){
        this.createController = new VendingMachineFactoryCreateController(createView, createModel, select);
    }

    /**
     * This method will set up the special vending machine model from the custom creation model
     * @param model holds the newly created specialvendingmachinemodel from the user input in custom creation
     */
    public void setSpecialVendingMachineModel( SpecialVendingMachineModel model){
        specialVendingMachineModel = model;
    }

    /**
     * This method will set up the special vending machine controller with the proper parameters
     *
     * @param specialVendingMachineView contains the created special vending machine view from the constructor
     * @param specialVendingMachineModel contains the created special vending machine model after copying it from the create classes
     */
    public void setSpecialVendingMachineController( SpecialVendingMachineView specialVendingMachineView, SpecialVendingMachineModel specialVendingMachineModel ){
        specialVendingMachineController = new SpecialVendingMachineController(specialVendingMachineView, specialVendingMachineModel);
    }

    /**
     * This method will set up the normal vending machine model from the custom creation model
     *
     * @param model holds the newly created normalvendingmachinemodel from the user input in custom creation
     */
    public void setNormalVendingMachineModel( VendingMachineModel model){
        normalVendingMachineModel = model;
    }

    /**
     *  This method will set up the special vending machine controller with the proper parameters
     *
     * @param vendingMachineView contains the created normal vending machine view from the constructor
     * @param vendingMachineModel contains the created vending machine model after copying it from the create classes
     */
    public void setNormalVendingController( VendingMachineView vendingMachineView, VendingMachineModel vendingMachineModel ){
        this.normalVendingController = new VendingMachineController(vendingMachineView, vendingMachineModel);
    }




    public VendingMachineFactoryCreateModel getCreateModel() {
        return createModel;
    }
    public VendingMachineFactoryCreateView getCreateView() {
        return createView;
    }
    public VendingMachineFactoryCreateController getCreateController() {
        return createController;
    }

    public VendingMachineView getNormalVendingMachineView() {
        return normalVendingMachineView;
    }
    public VendingMachineModel getNormalVendingMachineModel() {
        return normalVendingMachineModel;
    }

    public VendingMachineController getNormalVendingController() {
        return normalVendingController;
    }

    public SpecialVendingMachineView getSpecialVendingMachineView() {
        return specialVendingMachineView;
    }

    public SpecialVendingMachineModel getSpecialVendingMachineModel() {
        return specialVendingMachineModel;
    }

    public SpecialVendingMachineController getSpecialVendingMachineController() {
        return specialVendingMachineController;
    }

    //Attributes for Normal Vending Machine
    private VendingMachineView normalVendingMachineView;
    private VendingMachineController normalVendingController;
    private VendingMachineModel normalVendingMachineModel;

    //Attributes for Special Vending Machine
    private SpecialVendingMachineModel specialVendingMachineModel;
    private SpecialVendingMachineView specialVendingMachineView;
    private SpecialVendingMachineController specialVendingMachineController;

    //Attributes for Custom Creation
    private VendingMachineFactoryCreateController createController;
    private VendingMachineFactoryCreateView createView;
    private VendingMachineFactoryCreateModel createModel;




}
