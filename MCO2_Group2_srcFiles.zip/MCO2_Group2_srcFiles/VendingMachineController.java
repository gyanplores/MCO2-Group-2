import javax.swing.*;
import javax.swing.event.AncestorListener;
import java.util.ArrayList;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.Flow;

/**
 * This class is responsible for the main user's action for the vending machine.
 * @author Group 2(Flores, Ranigo)
 */
public class VendingMachineController {
    public VendingMachineController( VendingMachineView vendingMachineView, VendingMachineModel normalMachineModel ){
        this.vendingMachineView = vendingMachineView;
        this.normalVendingMachine = normalMachineModel;
        this.vendingMachineView.setTextLbl(initializeStartupTextScreen());
        initializeButtons();
        initializeEnterButton();
        initializeDeleteButton();
        initializeEnterCoin();
        initializeEnterBill();
        printProducts();
        initializeGetChange();
    }

    /**
     * This method will make the GUI visible to the user
     */
    public void makeVisible(){
        vendingMachineView.getMainFrame().setVisible(true);
    }

    private void initializeButtons(){
        this.vendingMachineView.setNumBtn(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() instanceof JButton) {
                    if( vendingMachineView.getKeypadScreen().getText() == null ){
                        vendingMachineView.setKeypadScreen( ((JButton) e.getSource()).getText(), null);
                    }
                    else{
                        vendingMachineView.setKeypadScreen(((JButton) e.getSource()).getText(), vendingMachineView.getKeypadScreen().getText()  );
                    }
                }
            }
        });
    }
    private void initializeEnterButton(){
        this.vendingMachineView.setEnterButton(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                int number;

                if( vendingMachineView.getKeypadScreen().getText().isEmpty() ){
                    number = 0;
                }else
                    number = Integer.parseInt(vendingMachineView.getKeypadScreen().getText()) - 1;
                vendingMachineView.setKeypadScreen(null, null);
                if (number < normalVendingMachine.getSlots().length && number > 0) {
                    //If statement below will check if users money is sufficient and if the item is in stock
                    if (normalVendingMachine.getSlots()[number].getItem() != null) {
                        if (normalVendingMachine.getCashRegister().buyCheck(normalVendingMachine.getSlots()[number].getItem().getPrice(), normalVendingMachine.getSlots()[number].getItemAmount())){
                            //If statement bellow will check if the vending machine can supply the change
                            if (normalVendingMachine.getCashRegister().changeCheck(normalVendingMachine.getCashRegister().getUserMoney() - normalVendingMachine.getSlots()[number].getItem().getPrice())) {
                                vendingMachineView.setTextLbl(initializeConfirmBuyScreen(number));

                                vendingMachineView.setYesButton(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        if(e.getSource() instanceof JButton){
                                            if(((JButton) e.getSource()).getText() == "Yes"){
                                                normalVendingMachine.getCashRegister().buyProduct(normalVendingMachine.getSlots()[number].getItem().getPrice());
                                                normalVendingMachine.getSlots()[number].removeItem();
                                                printProducts();
                                                vendingMachineView.setDispenseLbl( initializeDispense( number ) );
                                                vendingMachineView.setTextLbl(initializeStartupTextScreen());
                                            }
                                        }
                                    }
                                });

                                vendingMachineView.setNoButton(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        if(e.getSource() instanceof JButton){
                                            if(((JButton) e.getSource()).getText() == "No"){
                                                vendingMachineView.setTextLbl(initializeStartupTextScreen());
                                            }
                                        }
                                    }
                                });

                            }
                        }
                    }
                }
            }
        });
    }
    private void initializeDeleteButton(){
        this.vendingMachineView.setDeleteButton(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() instanceof JButton){
                    vendingMachineView.setKeypadScreen(null,null);
                }
            }
        });
    }
    private void initializeEnterCoin(){
        this.vendingMachineView.setEnterCoin(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() instanceof JButton){
                    switch( vendingMachineView.getCoinBox().getSelectedIndex() ){
                        case 1:
                            normalVendingMachine.getCashRegister().addDenomination(1);
                            vendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                        case 2:
                            normalVendingMachine.getCashRegister().addDenomination(2);
                            vendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                        case 3:
                            normalVendingMachine.getCashRegister().addDenomination(3);
                            vendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                        case 4:
                            normalVendingMachine.getCashRegister().addDenomination(4);
                            vendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                    }

                }
            }
        });
    }
    private void initializeEnterBill(){
        this.vendingMachineView.setEnterBill(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() instanceof JButton){
                    switch( vendingMachineView.getBillBox().getSelectedIndex() ){
                        case 1:
                            normalVendingMachine.getCashRegister().addDenomination(5);
                            vendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                        case 2:
                            normalVendingMachine.getCashRegister().addDenomination(6);
                            vendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                        case 3:
                            normalVendingMachine.getCashRegister().addDenomination(7);
                            vendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                        case 4:
                            normalVendingMachine.getCashRegister().addDenomination(8);
                            vendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                        case 5:
                            normalVendingMachine.getCashRegister().addDenomination(9);
                            vendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                        case 6:
                            normalVendingMachine.getCashRegister().addDenomination(10);
                            vendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                    }
                }
            }
        });
    }
    private void initializeGetChange(){
        this.vendingMachineView.setGiveChange(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource() instanceof JButton){
                    String result;
                    double val = normalVendingMachine.getCashRegister().getUserMoney();
                    int[] list = normalVendingMachine.getCashRegister().giveChange();
                    result = changeHelper(list, val);
                    vendingMachineView.setChangeLbl(result);
                    vendingMachineView.setTextLbl(initializeStartupTextScreen());

                }
            }
        });
    }


    /**
     * This method is responsible for displaying the startup text for the vending machine
     * @return The string of texts for startup.
     */
    private String initializeStartupTextScreen(){

        return  "\n\n\n\n"
               +"        Welcome to Special\n"
               +"         Vending Machine!\n\n"
               +"          User Money: "+normalVendingMachine.getCashRegister().getUserMoney()+"\n\n\n\n"
               +"   Select Your Chosen Product!\n\n\n\n";
    }

    /**
     * This method is responsible for displaying the confirmation of buying texts for a specific item.
     * @return The string of texts for confirm buy screen..
     */
    private String initializeConfirmBuyScreen(int number){
        return "\n\n\n\n"
              +"   Confirm Purchase?\n\n"
              +"   Name: "+normalVendingMachine.getSlots()[number].getItem().getName()+"\n"
              +"   Price: "+normalVendingMachine.getSlots()[number].getItem().getPrice()+"\n"
              +"  Calories: "+normalVendingMachine.getSlots()[number].getItem().getCalories()+"\n\n"
              +"   Press Enter to Continue\n"
              +"   Press Del to Go Back"  ;
    }

    /**
     * This method is responsible for displaying the different slot numbers and its items for the vending machine.
     * @return The string of each slot and item details..
     */
    private String initializeItemSlots(int i){
        return "\n  Slot # " + (i+1)+"\n"
              +"  Name: "+normalVendingMachine.getSlots()[i].getItem().getName()+"\n"
              +"  Price: "+normalVendingMachine.getSlots()[i].getItem().getPrice()+"\n"
              +"  Calories: "+normalVendingMachine.getSlots()[i].getItem().getCalories()+"\n"
              +"  Quantity: "+normalVendingMachine.getSlots()[i].getItemAmount()+"\n\n"
              +"--------------------------------------------------------------------\n"  ;
    }

    /**
     * This method is responsible for displaying the empty slots with no items as texts.
     * @param i index number for the empty slot.
     * @return The string of texts for the empty slot.
     */
    private String initializeEmptySlot(int i){
        return   "\n   Slot # " + (i+1)+"\n"
                +"   Name: Slot is Empty\n"
                +"   Price: ----\n"
                +"   Calories: ----\n"
                +"   Quantity: ----\n\n"
                +"--------------------------------------------------------------------\n"  ;
    }

    /**
     * This method is responsible for knowing what to display in terms of empty/occupied slots and items.
     */
    private void printProducts(){
        int i = 0, count = 0;
        int j;

        for(j = 0; j < 3 && i < normalVendingMachine.getSlots().length; j++) {
            if( normalVendingMachine.getSlots()[i].getItem() == null ){
                if (count <= 2){
                    vendingMachineView.setItemsLbl(j, initializeEmptySlot(i));
                }
                else
                    vendingMachineView.setItemsLbl(j, vendingMachineView.getItemsLbl()[j].getText().concat(initializeEmptySlot(i)));
            }else{
                if (count <= 2) {
                    vendingMachineView.setItemsLbl(j, initializeItemSlots(i));
                }
               else
                   vendingMachineView.setItemsLbl(j, vendingMachineView.getItemsLbl()[j].getText().concat(initializeItemSlots(i)));
            }
            i++;
            if (j == 2)
                j = -1;
            count++;
        }
    }

    /**
     * This method is responsible for process for displaying the texts for change money.
     * @param change Types of money used(500 peso bills, 1000 peso bills, etc.
     * @param val Total amount of money for change.
     * @return All of the texts containing the details of the amount of change processed/
     */
    private String changeHelper(int[] change , double val){
        String[] denom = new String[10];
        String collection = "";
        int i = 0, j = 0;

        do{
            if(change[i] != 0){
                switch(i){
                    case 0:
                        denom[j] = "Amount of 1000 Peso Bills: "+change[i]+"\n";
                        j++;
                        break;
                    case 1:
                        denom[j] = "  Amount of 500 Peso Bills: "+change[i]+"\n";
                        j++;
                        break;
                    case 2:
                        denom[j] = "  Amount of 200 Peso Bills: "+change[i]+"\n";
                        j++;
                        break;
                    case 3:
                        denom[j] = "  Amount of 100 Peso Bills: "+change[i]+"\n";
                        j++;
                        break;
                    case 4:
                        denom[j] = "  Amount of 50 Peso Bills: "+change[i]+"\n";
                        j++;
                        break;
                    case 5:
                        denom[j] = "  Amount of 20 Peso Bills: "+change[i]+"\n";
                        j++;
                        break;
                    case 6:
                        denom[j] = "  Amount of 20 Peso Coins: "+change[i]+"\n";
                        j++;
                        break;
                    case 7:
                        denom[j] = "  Amount of 10 Peso Coins: "+change[i]+"\n";
                        j++;
                        break;
                    case 8:
                        denom[j] = "  Amount of 5 Peso Coins: "+change[i]+"\n";
                        j++;
                        break;
                    case 9:
                        denom[j] = "  Amount of 1 Peso Coins: "+change[i]+"\n";
                        j++;
                }
            }

            i++;
        }while( i < 10 );

        boolean first = true;

        for( int g = 0 ; g < denom.length ; g++ ){
            if(denom[g] != null){
                if(first){
                    collection = denom[g];
                    first = false;
                }
                else{
                    collection = collection.concat(denom[g]);
                }
            }
        }
        collection = collection.concat("  Total Amount is: "+val);

        return collection;
    }

    /**
     * This method is responsible for displaying the texts for received item.
     * @param i Index for item slot.
     * @return The text string for item dispensed.
     */
    private String initializeDispense(int i){
        return "\n"
              +"      You received:\n"
              +"      "+normalVendingMachine.getSlots()[i].getItem().getName();
    }



    //Attributes
    private VendingMachineView vendingMachineView;
    private VendingMachineModel normalVendingMachine;
}
