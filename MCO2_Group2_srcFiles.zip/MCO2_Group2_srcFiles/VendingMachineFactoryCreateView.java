import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionListener;

/**
 * This class is responsible for the image portion of the GUI for the custom creation
 *
 * @author Group2(Flores, Ranigo)
 */
public class VendingMachineFactoryCreateView {
    /**
     * this constructor will initialize the different attributes and processes for the GUI
     */
    public VendingMachineFactoryCreateView(){
        this.mainFrame = new JFrame("MyFactoryCreate");

        this.mainFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.mainFrame.setLayout(null);
        this.mainFrame.setSize(500, 500);
        this.mainFrame.setResizable(false);
        this.mainFrame.setVisible(false);

        Font font = new Font("Helvetica", 1, 12);
        Font font2 = new Font("Helvetica", 1, 14);

        this.introText = new JTextArea();
        this.introText.setText("     Welcome! This is the place to\n  create your own vending machine");
        this.introText.setBounds(130, 30, 200, 40);
        this.introText.setFont(new Font("Helvetica", 1, 12));
        this.introText.setBorder(BorderFactory.createLineBorder(Color.black));
        this.introText.setEditable(false);

        this.input1 = new JTextField();
        this.input1.setColumns(30);
        this.input1.setBounds(80,100,220,30 );
        this.input2 = new JTextField();
        this.input2.setColumns(30);
        this.input2.setBounds(80,250,220,30 );

        this.submit1 = new JButton("Submit");
        this.submit1.setBounds(320,100,70,30 );
        submit1.setBorder(BorderFactory.createLineBorder(Color.black));
        this.submit2 = new JButton("Submit");
        this.submit2.setBounds(320,250,70,30 );
        submit2.setBorder(BorderFactory.createLineBorder(Color.black));

        this.preset = new JButton("Preset");
        this.preset.setBorder(BorderFactory.createLineBorder(Color.black));
        this.custom = new JButton("Custom");
        this.custom.setBorder(BorderFactory.createLineBorder(Color.black));

        JPanel buttonHold = new JPanel(new GridLayout(1, 3));
        buttonHold.setBounds(60, 350, 350, 75);
        buttonHold.add(preset);
        buttonHold.add(custom);

        this.mainFrame.add(introText);
        this.mainFrame.add(input1);
        this.mainFrame.add(input2);
        this.mainFrame.add(submit1);
        this.mainFrame.add(submit2);
        this.mainFrame.add(buttonHold);
    }


    public void setInput1(String text){
        this.input1.setText(text);
    }

    public void setInput2(String text){
        this.input2.setText(text);
    }

    public void setPreset(ActionListener actionListener){
        this.preset.addActionListener(actionListener);
    }

    public void setCustom(ActionListener actionListener){
        this.custom.addActionListener(actionListener);
    }

    public void setSubmit1(ActionListener actionListener){
        this.submit1.addActionListener(actionListener);
    }

    public void setSubmit2(ActionListener actionListener){
        this.submit2.addActionListener(actionListener);
    }

    public void setIntroText(String text){
        this.introText.setText(text);
    }

    public JTextField getInput1(){
        return input1;
    }

    public JTextField getInput2(){
        return input2;
    }
    public JFrame getMainFrame(){return mainFrame;}

    private JFrame mainFrame;
    private JTextArea introText;
    private JTextField input1, input2;
    private JTextArea textLbl;
    private JButton preset, custom, submit1, submit2;
}
