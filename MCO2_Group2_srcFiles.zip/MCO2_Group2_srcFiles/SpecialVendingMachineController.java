import javax.swing.*;
import javax.swing.event.AncestorListener;
import java.util.ArrayList;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.Flow;

/**
 * This class is responsible for the main user's action for the vending machine.
 * @author Group 2(Flores, Ranigo)
 */
public class SpecialVendingMachineController{
    /**
     * The constructor initializes the main aspects of the gui panels and the user interactions.
     *
     * @param specialVendingMachineView   Initializes the view for a vending machine.
     * @param specialVendingMachine Initializes the special vending machine components.
     */
    public SpecialVendingMachineController(SpecialVendingMachineView specialVendingMachineView, SpecialVendingMachineModel specialVendingMachine) {
        this.specialVendingMachineView = specialVendingMachineView;
        this.specialVendingMachine = specialVendingMachine;
        this.specialVendingMachineView.setTextLbl(initializeStartupTextScreen());
        initializeButtons();
        initializeEnterButton();
        initializeDeleteButton();
        initializeEnterCoin();
        initializeEnterBill();
        printProducts();
        initializeGetChange();
    }

    /**
     * This method will make the GUI visible to the user
     */
    public void makeVisible(){
        specialVendingMachineView.getMainFrame().setVisible(true);
    }

    private void initializeButtons(){
        this.specialVendingMachineView.setNumBtn(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() instanceof JButton) {
                    if( specialVendingMachineView.getKeypadScreen().getText() == null ){
                        specialVendingMachineView.setKeypadScreen( ((JButton) e.getSource()).getText(), null);
                    }
                    else{
                        specialVendingMachineView.setKeypadScreen(((JButton) e.getSource()).getText(), specialVendingMachineView.getKeypadScreen().getText()  );
                    }
                }
            }
        });
    }
    private void initializeEnterButton(){
        this.specialVendingMachineView.setEnterButton(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                int number;

                if( specialVendingMachineView.getKeypadScreen().getText().isEmpty() ){
                    number = 0;
                }else
                    number = Integer.parseInt(specialVendingMachineView.getKeypadScreen().getText()) - 1;
                specialVendingMachineView.setKeypadScreen(null, null);
                if (number < specialVendingMachine.getSlots().length && number >0) {
                    //If statement below will check if users money is sufficient and if the item is in stock
                    if (specialVendingMachine.getSlots()[number].getItem() != null) {
                        /*if(number == 0){
                            specialVendingMachineView.setTextLbl(initializeSpecialMenu());
                            int j = 0;
                            boolean cond = true;
                            String save = specialVendingMachineView.getTextLbl().getText();
                            double calo = 0;
                            double prices = 0;
                            do{
                                specialVendingMachineView.setEnterButton(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        if(e.getSource() instanceof JButton){
                                            int chosen = Integer.parseInt(specialVendingMachineView.getKeypadScreen().getText()) - 1;
                                            if( chosen > 1 && chosen < specialVendingMachine.getSlots().length){
                                                if(specialVendingMachine.getSlots()[number].getItemAmount() > 0){
                                                    //save = save.concat(initializeSpecialMenuAdd(number));
                                                    //calo = calo + specialVendingMachine.getSlots()[number].getItem().getCalories();
                                                    //prices = prices + specialVendingMachine.getSlots()[number].getItem().getPrice();
                                                    //specialVendingMachineView.setTextLbl(save);
                                                }
                                            }
                                        }
                                    }
                                });

                                specialVendingMachineView.setYesButton(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {

                                    }
                                });

                            }while( cond == true );

                        }*/


                        if (specialVendingMachine.getCashRegister().buyCheck(specialVendingMachine.getSlots()[number].getItem().getPrice(), specialVendingMachine.getSlots()[number].getItemAmount())){
                            //If statement bellow will check if the vending machine can supply the change
                            if (specialVendingMachine.getCashRegister().changeCheck(specialVendingMachine.getCashRegister().getUserMoney() - specialVendingMachine.getSlots()[number].getItem().getPrice())) {
                                specialVendingMachineView.setTextLbl(initializeConfirmBuyScreen(number));

                                specialVendingMachineView.setYesButton(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        if(e.getSource() instanceof JButton){
                                            if(((JButton) e.getSource()).getText() == "Yes"){
                                                specialVendingMachine.getCashRegister().buyProduct(specialVendingMachine.getSlots()[number].getItem().getPrice());
                                                specialVendingMachine.getSlots()[number].removeItem();
                                                printProducts();
                                                specialVendingMachineView.setDispenseLbl( initializeDispense( number ) );
                                                specialVendingMachineView.setTextLbl(initializeStartupTextScreen());
                                            }
                                        }
                                    }
                                });

                                specialVendingMachineView.setNoButton(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        if(e.getSource() instanceof JButton){
                                            if(((JButton) e.getSource()).getText() == "No"){
                                                specialVendingMachineView.setTextLbl(initializeStartupTextScreen());
                                            }
                                        }
                                    }
                                });

                            }
                        }
                    }
                }
            }
        });
    }
    private void initializeDeleteButton(){
        this.specialVendingMachineView.setDeleteButton(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() instanceof JButton){
                    specialVendingMachineView.setKeypadScreen(null,null);
                }
            }
        });
    }
    private void initializeEnterCoin(){
        this.specialVendingMachineView.setEnterCoin(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() instanceof JButton){
                    switch( specialVendingMachineView.getCoinBox().getSelectedIndex() ){
                        case 1:
                            specialVendingMachine.getCashRegister().addDenomination(1);
                            specialVendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                        case 2:
                            specialVendingMachine.getCashRegister().addDenomination(2);
                            specialVendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                        case 3:
                            specialVendingMachine.getCashRegister().addDenomination(3);
                            specialVendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                        case 4:
                            specialVendingMachine.getCashRegister().addDenomination(4);
                            specialVendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                    }

                }
            }
        });
    }
    private void initializeEnterBill(){
        this.specialVendingMachineView.setEnterBill(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() instanceof JButton){
                    switch( specialVendingMachineView.getBillBox().getSelectedIndex() ){
                        case 1:
                            specialVendingMachine.getCashRegister().addDenomination(5);
                            specialVendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                        case 2:
                            specialVendingMachine.getCashRegister().addDenomination(6);
                            specialVendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                        case 3:
                            specialVendingMachine.getCashRegister().addDenomination(7);
                            specialVendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                        case 4:
                            specialVendingMachine.getCashRegister().addDenomination(8);
                            specialVendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                        case 5:
                            specialVendingMachine.getCashRegister().addDenomination(9);
                            specialVendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                        case 6:
                            specialVendingMachine.getCashRegister().addDenomination(10);
                            specialVendingMachineView.setTextLbl(initializeStartupTextScreen());
                            break;
                    }
                }
            }
        });
    }
    private void initializeGetChange(){
        this.specialVendingMachineView.setGiveChange(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource() instanceof JButton){
                    String result;
                    double val = specialVendingMachine.getCashRegister().getUserMoney();
                    int[] list = specialVendingMachine.getCashRegister().giveChange();
                    result = changeHelper(list, val);
                    specialVendingMachineView.setChangeLbl(result);
                    specialVendingMachineView.setTextLbl(initializeStartupTextScreen());

                }
            }
        });
    }
    
    
    
    /**
     * This method is responsible for displaying the startup text for the vending machine
     * @return The string of texts for startup.
     */
    private String initializeStartupTextScreen(){

        return  "\n\n\n\n"
                +"        Welcome to Special\n"
                +"         Vending Machine!\n\n"
                +"          User Money: "+specialVendingMachine.getCashRegister().getUserMoney()+"\n\n\n\n"
                +"   Select Your Chosen Product!\n\n\n\n";
    }

    /**
     * This method is responsible for displaying the confirmation of buying texts for a specific item.
     * @return The string of texts for confirm buy screen..
     */
    private String initializeConfirmBuyScreen(int number){
        return "\n\n\n\n"
                +"   Confirm Purchase?\n\n"
                +"   Name: "+specialVendingMachine.getSlots()[number].getItem().getName()+"\n"
                +"   Price: "+specialVendingMachine.getSlots()[number].getItem().getPrice()+"\n"
                +"  Calories: "+specialVendingMachine.getSlots()[number].getItem().getCalories()+"\n\n"
                +"   Press Enter to Continue\n"
                +"   Press Del to Go Back"  ;
    }

    /**
     * This method is responsible for displaying the different slot numbers and its items for the vending machine.
     * @return The string of each slot and item details..
     */
    private String initializeItemSlots(int i){
        return "\n  Slot # " + (i+1)+"\n"
                +"  Name: "+specialVendingMachine.getSlots()[i].getItem().getName()+"\n"
                +"  Price: "+specialVendingMachine.getSlots()[i].getItem().getPrice()+"\n"
                +"  Calories: "+specialVendingMachine.getSlots()[i].getItem().getCalories()+"\n"
                +"  Quantity: "+specialVendingMachine.getSlots()[i].getItemAmount()+"\n\n"
                +"--------------------------------------------------------------------\n"  ;
    }

    /**
     * This method is responsible for displaying the empty slots with no items as texts.
     * @param i index number for the empty slot.
     * @return The string of texts for the empty slot.
     */
    private String initializeEmptySlot(int i){
        return   "\n   Slot # " + (i+1)+"\n"
                +"   Name: Slot is Empty\n"
                +"   Price: ----\n"
                +"   Calories: ----\n"
                +"   Quantity: ----\n\n"
                +"--------------------------------------------------------------------\n"  ;
    }

    /**
     * This method is responsible for knowing what to display in terms of empty/occupied slots and items.
     */
    private void printProducts(){
        int i = 0, count = 0;
        int j;

        for(j = 0; j < 3 && i < specialVendingMachine.getSlots().length; j++) {
            if( specialVendingMachine.getSlots()[i].getItem() == null ){
                if (count <= 2){
                    specialVendingMachineView.setItemsLbl(j, initializeEmptySlot(i));
                }
                else
                    specialVendingMachineView.setItemsLbl(j, specialVendingMachineView.getItemsLbl()[j].getText().concat(initializeEmptySlot(i)));
            }else{
                if (count <= 2) {
                    specialVendingMachineView.setItemsLbl(j, initializeItemSlots(i));
                }
                else
                    specialVendingMachineView.setItemsLbl(j, specialVendingMachineView.getItemsLbl()[j].getText().concat(initializeItemSlots(i)));
            }
            i++;
            if (j == 2)
                j = -1;
            count++;
        }
    }

    /**
     * This method is responsible for process for displaying the texts for change money.
     * @param change Types of money used(500 peso bills, 1000 peso bills, etc.
     * @param val Total amount of money for change.
     * @return All of the texts containing the details of the amount of change processed/
     */
    private String changeHelper(int[] change , double val){
        String[] denom = new String[10];
        String collection = "";
        int i = 0, j = 0;

        do{
            if(change[i] != 0){
                switch(i){
                    case 0:
                        denom[j] = "Amount of 1000 Peso Bills: "+change[i]+"\n";
                        j++;
                        break;
                    case 1:
                        denom[j] = "  Amount of 500 Peso Bills: "+change[i]+"\n";
                        j++;
                        break;
                    case 2:
                        denom[j] = "  Amount of 200 Peso Bills: "+change[i]+"\n";
                        j++;
                        break;
                    case 3:
                        denom[j] = "  Amount of 100 Peso Bills: "+change[i]+"\n";
                        j++;
                        break;
                    case 4:
                        denom[j] = "  Amount of 50 Peso Bills: "+change[i]+"\n";
                        j++;
                        break;
                    case 5:
                        denom[j] = "  Amount of 20 Peso Bills: "+change[i]+"\n";
                        j++;
                        break;
                    case 6:
                        denom[j] = "  Amount of 20 Peso Coins: "+change[i]+"\n";
                        j++;
                        break;
                    case 7:
                        denom[j] = "  Amount of 10 Peso Coins: "+change[i]+"\n";
                        j++;
                        break;
                    case 8:
                        denom[j] = "  Amount of 5 Peso Coins: "+change[i]+"\n";
                        j++;
                        break;
                    case 9:
                        denom[j] = "  Amount of 1 Peso Coins: "+change[i]+"\n";
                        j++;
                }
            }

            i++;
        }while( i < 10 );

        boolean first = true;

        for( int g = 0 ; g < denom.length ; g++ ){
            if(denom[g] != null){
                if(first){
                    collection = denom[g];
                    first = false;
                }
                else{
                    collection = collection.concat(denom[g]);
                }
            }
        }
        collection = collection.concat("  Total Amount is: "+val);

        return collection;
    }

    /**
     * This method is responsible for displaying the texts for received item.
     * @param i Index for item slot.
     * @return The text string for item dispensed.
     */
    private String initializeDispense(int i){
        return "\n"
                +"      You received:\n"
                +"      "+specialVendingMachine.getSlots()[i].getItem().getName();
    }
/*
    private String initializeSpecialMenu(){
        return "    Selected Special Pasta!\n"
              +"  Please Choose Products to Add \n"
              +"     on your Custom Pasta!\n";
    }

    private String initializeSpecialMenuAdd( int number ){
        return "      "+specialVendingMachine.getSlots()[number].getItem().getName()+"\n";
    }
*/


    //Attributes
    private SpecialVendingMachineView specialVendingMachineView;
    private SpecialVendingMachineModel specialVendingMachine;
}
